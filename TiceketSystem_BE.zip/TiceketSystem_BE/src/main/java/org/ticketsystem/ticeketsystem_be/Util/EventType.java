package org.ticketsystem.ticeketsystem_be.Util;

public enum EventType {
    CONCERT,
    SPORTS,
    THEATER,
    CONFERENCE,
    EXHIBITION
}
