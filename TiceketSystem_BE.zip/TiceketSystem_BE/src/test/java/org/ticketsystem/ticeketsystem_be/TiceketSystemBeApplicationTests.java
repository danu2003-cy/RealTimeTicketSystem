package org.ticketsystem.ticeketsystem_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiceketSystemBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
